#!/bin/bash

read -p "Diretório 1: " diretorio_1
read -p "Diretório 2: " diretorio_2
read -p "Diretório 3: " diretorio_2

ls ${diretorio_1}
ls ${diretorio_2}
ls ${diretorio_3}
