#!/bin/bash
echo "Seja a mudança que você deseja ver no mundo!"
